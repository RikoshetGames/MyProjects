class BasicWord:
    def __init__(self, word, subwords):
        self.word = word
        self.subwords = subwords
        self.used_subwords = []

    def add_used_subword(self, subword):
        self.used_subwords.append(subword)

    def is_subword_valid(self, subword):
        return subword in self.subwords

    def get_used_subwords(self):
        return self.used_subwords

    def __repr__(self):
        return f"BasicWord(word={self.word}, subwords={self.subwords})"