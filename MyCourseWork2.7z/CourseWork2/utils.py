import random
import json
from basic_word import BasicWord

def load_random_word():
    with open("words.json", "r", encoding="utf8") as file: # Загрузка слов из файла (words.json)
        words = json.load(file)
        random_word = random.choice(words) # Выбор случайного слова
        return BasicWord(random_word["word"], random_word["subwords"])