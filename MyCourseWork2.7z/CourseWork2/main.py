from players import Player
from basic_word import BasicWord
from utils import load_random_word


def play_game():
    # Получаем имя игрока
    name = input("Введите имя игрока: ")
    player = Player(name)  # Создаем экземпляр класса игрока
    random_word = load_random_word() # Загружаем случайное слово
    # Приветствуем игрока
    print(f"Привет, {player.name}!")
    print(f"Составьте {len(random_word.subwords)} слов из слова {random_word.word.upper()}")
    print("Слова должны быть не короче 3 букв")
    print('Чтобы закончить игру, угадайте все слова или напишите "stop"')



    # Выводим первое слово
    print(f"Поехали, ваше первое слово?")
    print(random_word.word)

    # Игровой цикл
    while True:
        word = input("Пользователь: ")
        word = word.lower()  # Переводим в lowercase для удобства сравнения

        if word == "stop" or word == "стоп":  # Проверяем на выход
            break

        if len(word) < 3:  # Проверяем длину слова
            print("Программа: Слишком короткое слово")
            continue

        if not random_word.is_subword_valid(word):  # Проверяем вхождение слова в список подслов
            print("Программа: Неверно")
            continue

        if player.is_word_used(word):  # Проверяем использование слова
            print("Программа: Уже использовано")
            continue

        # Если все проверки пройдены успешно
        random_word.add_used_subword(word)  # Добавляем слово в использованные подслова
        if len(random_word.get_used_subwords()) == len(random_word.subwords):
            break
        player.add_used_word(word)  # Добавляем слово в использованные слова игрока
        print("Программа: Верно")

    # Выводим статистику
    print(f"Программа: Игра завершена, вы угадали {len(player.get_used_words())} слов!")


if __name__ == "__main__":
    play_game()
