class BasicWord:
    def __init__(self, word, subwords):
        self.word = word # исходное слово
        self.subwords = subwords # набор допустимых подслов
        self.used_subwords = [] # использованные слова

    def add_used_subword(self, subword):
        self.used_subwords.append(subword) # Добавляет использованное подслово в список

    def is_subword_valid(self, subword):
        return subword in self.subwords # Проверяет, является ли подслово допустимым

    def get_used_subwords(self):
        return self.used_subwords # Возвращает список использованных подслов

    def __repr__(self):
        return f"BasicWord(word={self.word}, subwords={self.subwords})"
