class Player:
    def __init__(self, name):
        self.name = name  # имя пользователя
        self.used_words = []  # использованные слова пользователя

    def get_used_words(self):
        return len(self.used_words) # Возвращает количество использованных слов

    def add_used_word(self, word):
        self.used_words.append(word) # Добавляет использованное слово в список

    def is_word_used(self, word):
        return word in self.used_words # Проверяет, было ли слово уже использовано

    def __repr__(self):
        return f"Player(name={self.name})"
